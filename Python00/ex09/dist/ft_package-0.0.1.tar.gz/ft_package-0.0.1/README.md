# ft_package

Un petit package Python contenant une fonction `count_in_list` qui compte les occurrences d’un élément dans une liste.