def count_in_list(lst: list, item: any) -> int:
    return lst.count(item)